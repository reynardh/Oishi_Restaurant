from django.contrib import admin
from .models import Booking, Table


admin.site.register(Booking)
admin.site.register(Table)
