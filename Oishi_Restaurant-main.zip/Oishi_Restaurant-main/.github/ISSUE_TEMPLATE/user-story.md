---
name: User Story
about: This is our default user story template
title: 'USER STOTY: <TITLE>'
labels: ''
assignees: ''

---

As a **role** I can ** capability** so that **received benefit**
